jre/bin/java -cp "lib/*" CodePuzzle
